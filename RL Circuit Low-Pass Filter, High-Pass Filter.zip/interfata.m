clear all;
close all;

   R=100;
   L=50;
   f=2;
   A=5;
   P=3;

start(R,L,f,A,P)


